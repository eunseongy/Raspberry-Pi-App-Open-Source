package com.example.dust_sensor_connection;


import android.bluetooth.BluetoothSocket;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class ConnectedThread extends Thread {
    private final BluetoothSocket mmSocket;
    private final InputStream mmInStream;
    private final OutputStream mmOutStream;

    public ConnectedThread(BluetoothSocket socket) {
    }

    @Override
    public void run() {

    }

    /* Call this from the main activity to send data to the remote device */
    public void write(String input) {

    }

    /* Call this from the main activity to shutdown the connection */
    public void cancel() {
    }
}